package com.te.javacollection.setex;

import java.util.Set;
import java.util.TreeSet;

public class EmployeeTestComparator {
	public static void main(String[] args) {
		Set<EmployeeComparator> employeeComparators = new TreeSet<EmployeeComparator>();
//		employeeComparators.add(new EmployeeComparator(10, "Deepankar", 20000));
//		employeeComparators.add(new EmployeeComparator(30, "Anil", 15000));
//		employeeComparators.add(new EmployeeComparator(20, "Sankar", 25000));
//		employeeComparators.add(new EmployeeComparator(40, "Bhupati", 40000));
		
//		for (EmployeeComparator employeeComparator : employeeComparators) {
//			System.out.println(employeeComparator);
//		}
		
		System.out.println(employeeComparators);
	}
}
