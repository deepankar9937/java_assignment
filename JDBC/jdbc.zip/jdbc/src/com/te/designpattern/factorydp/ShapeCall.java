package com.te.designpattern.factorydp;

public class ShapeCall {
	public void shapeCallMethod(Shape shape) {
		shape.getShapeInfo();
	}
}
