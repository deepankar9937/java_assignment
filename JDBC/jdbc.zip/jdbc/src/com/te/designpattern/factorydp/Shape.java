package com.te.designpattern.factorydp;

public interface Shape {
	public void getShapeInfo();
}
