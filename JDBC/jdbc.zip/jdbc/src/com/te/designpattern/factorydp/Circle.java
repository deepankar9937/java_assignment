package com.te.designpattern.factorydp;

public class Circle implements Shape{

	@Override
	public void getShapeInfo() {
		// TODO Auto-generated method stub
		System.out.println("It is a Circle");
	}

}
