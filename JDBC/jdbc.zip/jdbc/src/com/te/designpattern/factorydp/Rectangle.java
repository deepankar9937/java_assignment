package com.te.designpattern.factorydp;

public class Rectangle implements Shape{

	@Override
	public void getShapeInfo() {
		// TODO Auto-generated method stub
		System.out.println("It is a Rectangle");
	}

}
